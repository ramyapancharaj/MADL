package com.example.myapplication

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        val mail : EditText = findViewById(R.id.mail)
        val password : EditText = findViewById(R.id.password)
        val validate : Button = findViewById(R.id.validate)
        val clear : Button = findViewById(R.id.clear)
        validate.setOnClickListener {
            val mail = mail.text.toString().trim()
            val password = password.text.toString().trim()
            if(mail.isEmpty() || password.isEmpty())
            {
                Toast.makeText(this,"All fields are mandatory",Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            if(!email.matches(Regex("\\b[A-Za-z0-9.%+-]*rajalakshimi[A-Za-z0-9.%+-]*@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}\\b\n"))){
                Toast.makeText(this,"Invalid email",Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            if(!password.matches(Regex("^(?=.[A-Za-z])(?=.\\d)(?=.[@\$!%?&])[A-Za-z\\d@\$!%*?&]{8,}\$\n"))){
                Toast.makeText(this,"Invalid Password",Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            val intent:Intent= Intent(this, MainActivity3::class.java)
            startActivity(intent)
        }
        clear.setOnClickListener {
            mail.text.clear();
            password.text.clear()

        }
    }
            ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}